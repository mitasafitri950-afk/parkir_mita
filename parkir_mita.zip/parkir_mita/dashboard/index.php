<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

/*
|--------------------------------------------------------------------------
| DATA DASHBOARD
|--------------------------------------------------------------------------
*/

/* Total kendaraan */
$queryKendaraan = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM tb_kendaraan"
);

$dataKendaraan = mysqli_fetch_assoc($queryKendaraan);
$totalKendaraan = (int)$dataKendaraan['total'];


/* Total transaksi */
$queryTransaksi = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM tb_transaksi"
);

$dataTransaksi = mysqli_fetch_assoc($queryTransaksi);
$totalTransaksi = (int)$dataTransaksi['total'];


/*
|--------------------------------------------------------------------------
| KENDARAAN YANG MASIH PARKIR
|--------------------------------------------------------------------------
|
| Diasumsikan kendaraan masih parkir jika waktu_keluar masih NULL.
|
*/

$queryParkir = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM tb_transaksi
     WHERE waktu_keluar IS NULL"
);

$dataParkir = mysqli_fetch_assoc($queryParkir);
$totalParkir = (int)$dataParkir['total'];


/*
|--------------------------------------------------------------------------
| TOTAL PENDAPATAN
|--------------------------------------------------------------------------
*/

$queryPendapatan = mysqli_query(
    $koneksi,
    "SELECT COALESCE(SUM(biaya_total), 0) AS total
     FROM tb_transaksi
     WHERE waktu_keluar IS NOT NULL"
);

if (!$queryPendapatan) {
    die("Query Pendapatan Error: " . mysqli_error($koneksi));
}

$dataPendapatan = mysqli_fetch_assoc($queryPendapatan);
$totalPendapatan = (float)$dataPendapatan['total'];


/*
|--------------------------------------------------------------------------
| KENDARAAN MASUK HARI INI
|--------------------------------------------------------------------------
*/

$queryMasukHariIni = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM tb_transaksi
     WHERE DATE(waktu_masuk) = CURDATE()"
);

$dataMasukHariIni = mysqli_fetch_assoc($queryMasukHariIni);
$masukHariIni = (int)$dataMasukHariIni['total'];


/*
|--------------------------------------------------------------------------
| KENDARAAN KELUAR HARI INI
|--------------------------------------------------------------------------
*/

$queryKeluarHariIni = mysqli_query(
    $koneksi,
    "SELECT COUNT(*) AS total
     FROM tb_transaksi
     WHERE waktu_keluar IS NOT NULL
     AND DATE(waktu_keluar) = CURDATE()"
);

$dataKeluarHariIni = mysqli_fetch_assoc($queryKeluarHariIni);
$keluarHariIni = (int)$dataKeluarHariIni['total'];


/*
|--------------------------------------------------------------------------
| PENDAPATAN HARI INI
|--------------------------------------------------------------------------
*/

$queryPendapatanHariIni = mysqli_query(
    $koneksi,
    "SELECT COALESCE(SUM(biaya_total), 0) AS total
     FROM tb_transaksi
     WHERE waktu_keluar IS NOT NULL
     AND DATE(waktu_keluar) = CURDATE()"
);

$dataPendapatanHariIni = mysqli_fetch_assoc(
    $queryPendapatanHariIni
);

$pendapatanHariIni =
    (float)$dataPendapatanHariIni['total'];


/*
|--------------------------------------------------------------------------
| TRANSAKSI TERBARU
|--------------------------------------------------------------------------
*/

$queryTerbaru = mysqli_query(
    $koneksi,
    "SELECT
        t.id_transaksi,
        k.plat_nomor,
        k.jenis_kendaraan,
        t.waktu_masuk,
        t.waktu_keluar,
        t.biaya_total
     FROM tb_transaksi t
     LEFT JOIN tb_kendaraan k
        ON t.id_kendaraan = k.id_kendaraan
     ORDER BY t.id_transaksi DESC
     LIMIT 5"
);


/*
|--------------------------------------------------------------------------
| FORMAT RUPIAH
|--------------------------------------------------------------------------
*/

function rupiah($angka)
{
    return "Rp " . number_format(
        $angka,
        0,
        ",",
        "."
    );
}

?>

<!DOCTYPE html>

<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
Dashboard - Parkir Mita
</title>


<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
    background: #f4f6f9;
    color: #333;
}


/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
*/

.sidebar {
    position: fixed;
    left: 0;
    top: 0;

    width: 240px;
    height: 100vh;

    background: #1e3a8a;
    color: white;

    overflow-y: auto;
}

.logo {
    padding: 25px 15px;

    text-align: center;

    font-size: 20px;
    font-weight: bold;

    border-bottom: 1px solid
        rgba(255,255,255,.15);
}

.menu-title {
    padding: 20px 20px 8px;

    font-size: 11px;

    color: #bfdbfe;

    text-transform: uppercase;
}

.sidebar a {
    display: block;

    padding: 13px 20px;

    color: white;

    text-decoration: none;

    font-size: 14px;
}

.sidebar a:hover {
    background: #2563eb;
}

.sidebar a.active {
    background: #2563eb;
}


/*
|--------------------------------------------------------------------------
| USER SIDEBAR
|--------------------------------------------------------------------------
*/

.user-box {
    margin: 15px;

    padding: 15px;

    background: rgba(255,255,255,.1);

    border-radius: 8px;
}

.user-name {
    font-weight: bold;
}

.user-role {
    margin-top: 5px;

    font-size: 12px;

    color: #bfdbfe;

    text-transform: capitalize;
}


/*
|--------------------------------------------------------------------------
| CONTENT
|--------------------------------------------------------------------------
*/

.content {
    margin-left: 240px;

    padding: 25px;
}


/*
|--------------------------------------------------------------------------
| TOPBAR
|--------------------------------------------------------------------------
*/

.topbar {
    background: white;

    padding: 20px 25px;

    border-radius: 10px;

    margin-bottom: 25px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.06);

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;
}

.topbar h1 {
    margin: 0;

    color: #1e3a8a;

    font-size: 24px;
}

.topbar p {
    margin: 6px 0 0;

    color: #777;

    font-size: 14px;
}

.logout {
    padding: 10px 15px;

    background: #dc2626;

    color: white;

    border-radius: 7px;

    text-decoration: none;

    font-size: 13px;
}


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

.stats {
    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}

.stat-card {
    background: white;

    padding: 22px;

    border-radius: 10px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.06);

    position: relative;

    overflow: hidden;
}

.stat-icon {
    font-size: 30px;

    margin-bottom: 10px;
}

.stat-title {
    color: #777;

    font-size: 13px;

    margin-bottom: 7px;
}

.stat-number {
    font-size: 25px;

    font-weight: bold;

    color: #1e3a8a;
}


/*
|--------------------------------------------------------------------------
| DAILY STATS
|--------------------------------------------------------------------------
*/

.daily {
    display: grid;

    grid-template-columns:
        repeat(3, 1fr);

    gap: 18px;

    margin-bottom: 25px;
}

.daily-card {
    background: white;

    padding: 20px;

    border-radius: 10px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.06);
}

.daily-card h3 {
    margin: 0 0 12px;

    font-size: 15px;

    color: #555;
}

.daily-value {
    font-size: 22px;

    font-weight: bold;

    color: #2563eb;
}


/*
|--------------------------------------------------------------------------
| MAIN GRID
|--------------------------------------------------------------------------
*/

.main-grid {
    display: grid;

    grid-template-columns:
        2fr 1fr;

    gap: 20px;
}


/*
|--------------------------------------------------------------------------
| CARD
|--------------------------------------------------------------------------
*/

.card {
    background: white;

    border-radius: 10px;

    padding: 22px;

    box-shadow:
        0 2px 8px rgba(0,0,0,.06);
}

.card-header {
    display: flex;

    justify-content: space-between;

    align-items: center;

    margin-bottom: 20px;
}

.card-header h2 {
    margin: 0;

    font-size: 18px;

    color: #1e3a8a;
}

.card-link {
    font-size: 13px;

    color: #2563eb;

    text-decoration: none;
}


/*
|--------------------------------------------------------------------------
| TABLE
|--------------------------------------------------------------------------
*/

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;

    border-collapse: collapse;

    font-size: 13px;
}

th {
    background: #eff6ff;

    color: #1e3a8a;

    padding: 12px;

    text-align: left;
}

td {
    padding: 12px;

    border-bottom:
        1px solid #eee;
}

.status {
    display: inline-block;

    padding: 5px 9px;

    border-radius: 20px;

    font-size: 11px;
}

.status-masuk {
    background: #dcfce7;

    color: #166534;
}

.status-keluar {
    background: #fee2e2;

    color: #991b1b;
}


/*
|--------------------------------------------------------------------------
| QUICK MENU
|--------------------------------------------------------------------------
*/

.quick-menu {
    display: grid;

    grid-template-columns:
        repeat(2, 1fr);

    gap: 12px;
}

.quick-menu a {
    padding: 18px 10px;

    border-radius: 8px;

    background: #f8fafc;

    border: 1px solid #e5e7eb;

    color: #333;

    text-decoration: none;

    text-align: center;

    font-size: 13px;
}

.quick-menu a:hover {
    background: #eff6ff;

    border-color: #93c5fd;
}

.quick-icon {
    display: block;

    font-size: 25px;

    margin-bottom: 7px;
}


/*
|--------------------------------------------------------------------------
| RESPONSIVE
|--------------------------------------------------------------------------
*/

@media (max-width: 1100px) {

    .stats {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .daily {
        grid-template-columns:
            repeat(2, 1fr);
    }

    .main-grid {
        grid-template-columns: 1fr;
    }

}


@media (max-width: 700px) {

    .sidebar {
        position: relative;

        width: 100%;

        height: auto;
    }

    .content {
        margin-left: 0;

        padding: 15px;
    }

    .stats,
    .daily {
        grid-template-columns: 1fr;
    }

    .topbar {
        flex-direction: column;

        align-items: flex-start;
    }

}

</style>

</head>


<body>


<!-- =========================================================
     SIDEBAR
========================================================= -->

<div class="sidebar">

    <div class="logo">
        🚗 PARKIR MITA
    </div>


    <div class="user-box">

        <div class="user-name">

            👤

            <?php
            echo htmlspecialchars(
                $_SESSION['nama_lengkap']
            );
            ?>

        </div>

        <div class="user-role">

            <?php
            echo htmlspecialchars(
                $_SESSION['role']
            );
            ?>

        </div>

    </div>


    <div class="menu-title">
        Menu Utama
    </div>


    <a
        href="index.php"
        class="active"
    >
        🏠 Dashboard
    </a>


    <a href="../kendaraan/index.php">
        🚙 Data Kendaraan
    </a>


    <a href="../transaksi/masuk.php">
        🟢 Kendaraan Masuk
    </a>


    <a href="../transaksi/keluar.php">
        🔴 Kendaraan Keluar
    </a>


    <a href="../transaksi/riwayat.php">
        📋 Riwayat Transaksi
    </a>


    <div class="menu-title">
        Pengaturan
    </div>


    <a href="../area/index.php">
        📍 Area Parkir
    </a>


    <a href="../tarif/index.php">
        💰 Tarif Parkir
    </a>


    <a href="../laporan/index.php">
        📊 Laporan
    </a>


    <?php if (
        isset($_SESSION['role']) &&
        $_SESSION['role'] === 'admin'
    ) { ?>

        <div class="menu-title">
            Administrator
        </div>


        <a href="../user/index.php">
            👤 Data User
        </a>


        <a href="../log/index.php">
            📝 Log Aktivitas
        </a>

    <?php } ?>


    <div class="menu-title">
        Akun
    </div>


    <a href="../auth/logout.php">
        🚪 Logout
    </a>

</div>


<!-- =========================================================
     CONTENT
========================================================= -->

<div class="content">


    <!-- TOPBAR -->

    <div class="topbar">

        <div>

            <h1>
                Dashboard
            </h1>

            <p>
                Selamat datang di Sistem Informasi Parkir Mita.
            </p>

        </div>


        <a
            href="../auth/logout.php"
            class="logout"
            onclick="return confirm('Yakin ingin logout?')"
        >
            🚪 Logout
        </a>

    </div>


    <!-- =====================================================
         STATISTICS
    ====================================================== -->

    <div class="stats">


        <!-- TOTAL KENDARAAN -->

        <div class="stat-card">

            <div class="stat-icon">
                🚙
            </div>

            <div class="stat-title">
                Total Kendaraan
            </div>

            <div class="stat-number">

                <?php
                echo number_format(
                    $totalKendaraan,
                    0,
                    ",",
                    "."
                );
                ?>

            </div>

        </div>


        <!-- SEDANG PARKIR -->

        <div class="stat-card">

            <div class="stat-icon">
                🅿️
            </div>

            <div class="stat-title">
                Sedang Parkir
            </div>

            <div class="stat-number">

                <?php
                echo number_format(
                    $totalParkir,
                    0,
                    ",",
                    "."
                );
                ?>

            </div>

        </div>


        <!-- TOTAL TRANSAKSI -->

        <div class="stat-card">

            <div class="stat-icon">
                📋
            </div>

            <div class="stat-title">
                Total Transaksi
            </div>

            <div class="stat-number">

                <?php
                echo number_format(
                    $totalTransaksi,
                    0,
                    ",",
                    "."
                );
                ?>

            </div>

        </div>


        <!-- PENDAPATAN -->

        <div class="stat-card">

            <div class="stat-icon">
                💰
            </div>

            <div class="stat-title">
                Total Pendapatan
            </div>

            <div class="stat-number">

                <?php
                echo rupiah(
                    $totalPendapatan
                );
                ?>

            </div>

        </div>

    </div>


    <!-- =====================================================
         DATA HARI INI
    ====================================================== -->

    <div class="daily">


        <div class="daily-card">

            <h3>
                🟢 Kendaraan Masuk Hari Ini
            </h3>

            <div class="daily-value">

                <?php
                echo number_format(
                    $masukHariIni,
                    0,
                    ",",
                    "."
                );
                ?>

                kendaraan

            </div>

        </div>


        <div class="daily-card">

            <h3>
                🔴 Kendaraan Keluar Hari Ini
            </h3>

            <div class="daily-value">

                <?php
                echo number_format(
                    $keluarHariIni,
                    0,
                    ",",
                    "."
                );
                ?>

                kendaraan

            </div>

        </div>


        <div class="daily-card">

            <h3>
                💰 Pendapatan Hari Ini
            </h3>

            <div class="daily-value">

                <?php
                echo rupiah(
                    $pendapatanHariIni
                );
                ?>

            </div>

        </div>

    </div>


    <!-- =====================================================
         MAIN CONTENT
    ====================================================== -->

    <div class="main-grid">


        <!-- TRANSAKSI TERBARU -->

        <div class="card">

            <div class="card-header">

                <h2>
                    📋 Transaksi Terbaru
                </h2>

                <a
                    href="../transaksi/riwayat.php"
                    class="card-link"
                >
                    Lihat Semua →
                </a>

            </div>


            <div class="table-container">

                <table>

                    <thead>

                        <tr>

                            <th>
                                Plat Nomor
                            </th>

                            <th>
                                Jenis
                            </th>

                            <th>
                                Masuk
                            </th>

                            <th>
                                Status
                            </th>

                            <th>
                                Bayar
                            </th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php

                    if (
                        mysqli_num_rows(
                            $queryTerbaru
                        ) > 0
                    ) {

                        while (
                            $row =
                            mysqli_fetch_assoc(
                                $queryTerbaru
                            )
                        ) {

                            ?>

                            <tr>

                                <td>

                                    <strong>

                                    <?php
                                    echo htmlspecialchars(
                                        $row['plat_nomor']
                                        ?? '-'
                                    );
                                    ?>

                                    </strong>

                                </td>


                                <td>

                                    <?php
                                    echo htmlspecialchars(
                                        $row['jenis_kendaraan']
                                        ?? '-'
                                    );
                                    ?>

                                </td>


                                <td>

                                    <?php

                                    if (
                                        !empty(
                                            $row['waktu_masuk']
                                        )
                                    ) {

                                        echo date(
                                            "d/m/Y H:i",
                                            strtotime(
                                                $row['waktu_masuk']
                                            )
                                        );

                                    } else {

                                        echo "-";

                                    }

                                    ?>

                                </td>


                                <td>

                                <?php

                                if (
                                    empty(
                                        $row['waktu_keluar']
                                    )
                                ) {

                                    ?>

                                    <span
                                        class="status status-masuk"
                                    >
                                        Masih Parkir
                                    </span>

                                    <?php

                                } else {

                                    ?>

                                    <span
                                        class="status status-keluar"
                                    >
                                        Sudah Keluar
                                    </span>

                                    <?php

                                }

                                ?>

                                </td>


                                <td>

                                    <?php

                                    if (
                                        $row['total_bayar']
                                        !== null
                                    ) {

                                        echo rupiah(
                                            $row['total_bayar']
                                        );

                                    } else {

                                        echo "-";

                                    }

                                    ?>

                                </td>

                            </tr>

                            <?php

                        }

                    } else {

                        ?>

                        <tr>

                            <td
                                colspan="5"
                                style="
                                    text-align:center;
                                    padding:30px;
                                    color:#777;
                                "
                            >

                                Belum ada transaksi.

                            </td>

                        </tr>

                        <?php

                    }

                    ?>

                    </tbody>

                </table>

            </div>

        </div>


        <!-- MENU CEPAT -->

        <div class="card">

            <div class="card-header">

                <h2>
                    ⚡ Menu Cepat
                </h2>

            </div>


            <div class="quick-menu">


                <a
                    href="../kendaraan/tambah.php"
                >

                    <span class="quick-icon">
                        🚙
                    </span>

                    Tambah Kendaraan

                </a>


                <a
                    href="../transaksi/masuk.php"
                >

                    <span class="quick-icon">
                        🟢
                    </span>

                    Kendaraan Masuk

                </a>


                <a
                    href="../transaksi/keluar.php"
                >

                    <span class="quick-icon">
                        🔴
                    </span>

                    Kendaraan Keluar

                </a>


                <a
                    href="../laporan/index.php"
                >

                    <span class="quick-icon">
                        📊
                    </span>

                    Laporan

                </a>


                <a
                    href="../area/index.php"
                >

                    <span class="quick-icon">
                        📍
                    </span>

                    Area Parkir

                </a>


                <a
                    href="../tarif/index.php"
                >

                    <span class="quick-icon">
                        💰
                    </span>

                    Tarif Parkir

                </a>


            </div>

        </div>

    </div>

</div>


</body>

</html>