<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

$id = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}


/* CEK KENDARAAN */

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT
        id_kendaraan,
        plat_nomor
     FROM tb_kendaraan
     WHERE id_kendaraan = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) !== 1) {

    header("Location: index.php");
    exit;

}

$data = mysqli_fetch_assoc($result);

$plat_nomor = $data['plat_nomor'];


/* CEK TRANSAKSI */

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT id_transaksi
     FROM tb_transaksi
     WHERE id_kendaraan = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$transaksi = mysqli_stmt_get_result($stmt);


if (mysqli_num_rows($transaksi) > 0) {

    /*
     * Jangan hapus kendaraan yang sudah
     * mempunyai riwayat transaksi.
     */

    echo "

    <!DOCTYPE html>

    <html lang='id'>

    <head>

    <meta charset='UTF-8'>

    <title>Gagal Menghapus</title>

    <style>

    body {
        font-family: Arial;
        background: #f4f6f9;
    }

    .box {
        width: 500px;
        max-width: 90%;
        margin: 100px auto;
        background: white;
        padding: 30px;
        border-radius: 10px;
        text-align: center;
    }

    .error {
        background: #fee2e2;
        color: #991b1b;
        padding: 15px;
        border-radius: 7px;
        margin-bottom: 20px;
    }

    a {
        display: inline-block;
        padding: 10px 20px;
        background: #2563eb;
        color: white;
        text-decoration: none;
        border-radius: 7px;
    }

    </style>

    </head>

    <body>

    <div class='box'>

        <h2>⚠️ Kendaraan Tidak Dapat Dihapus</h2>

        <div class='error'>

            Kendaraan dengan plat
            <b>" .
            htmlspecialchars($plat_nomor) .
            "</b>
            sudah memiliki riwayat transaksi.

            <br><br>

            Data tidak dihapus agar riwayat parkir tetap aman.

        </div>

        <a href='index.php'>
            Kembali
        </a>

    </div>

    </body>

    </html>

    ";

    exit;
}


/* HAPUS */

$stmt = mysqli_prepare(
    $koneksi,
    "DELETE FROM tb_kendaraan
     WHERE id_kendaraan = ?"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);


if (mysqli_stmt_execute($stmt)) {


    /* LOG */

    $id_user =
        (int)$_SESSION['id_user'];

    $aktivitas =
        "Menghapus kendaraan " .
        $plat_nomor;

    $stmtLog = mysqli_prepare(
        $koneksi,
        "INSERT INTO tb_log_aktivitas
        (
            id_user,
            aktivitas
        )
        VALUES (?, ?)"
    );

    mysqli_stmt_bind_param(
        $stmtLog,
        "is",
        $id_user,
        $aktivitas
    );

    mysqli_stmt_execute($stmtLog);

}

header("Location: index.php");
exit;

?>