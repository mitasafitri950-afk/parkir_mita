<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

$id = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}


/* AMBIL DATA */

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT *
     FROM tb_kendaraan
     WHERE id_kendaraan = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) !== 1) {

    header("Location: index.php");
    exit;

}

$data = mysqli_fetch_assoc($result);

$error = "";


/* PROSES UPDATE */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $plat_nomor = strtoupper(
        trim($_POST['plat_nomor'] ?? "")
    );

    $jenis_kendaraan = trim(
        $_POST['jenis_kendaraan'] ?? ""
    );

    $warna = trim(
        $_POST['warna'] ?? ""
    );

    $pemilik = trim(
        $_POST['pemilik'] ?? ""
    );


    if (
        $plat_nomor === "" ||
        $jenis_kendaraan === "" ||
        $warna === "" ||
        $pemilik === ""
    ) {

        $error = "Semua data wajib diisi.";

    } else {


        /* CEK PLAT MILIK KENDARAAN LAIN */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id_kendaraan
             FROM tb_kendaraan
             WHERE plat_nomor = ?
             AND id_kendaraan != ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "si",
            $plat_nomor,
            $id
        );

        mysqli_stmt_execute($stmt);

        $cek = mysqli_stmt_get_result($stmt);


        if (mysqli_num_rows($cek) > 0) {

            $error =
                "Plat nomor tersebut sudah digunakan kendaraan lain.";

        } else {


            /* UPDATE */

            $stmt = mysqli_prepare(
                $koneksi,
                "UPDATE tb_kendaraan
                 SET
                    plat_nomor = ?,
                    jenis_kendaraan = ?,
                    warna = ?,
                    pemilik = ?
                 WHERE id_kendaraan = ?"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "ssssi",
                $plat_nomor,
                $jenis_kendaraan,
                $warna,
                $pemilik,
                $id
            );


            if (mysqli_stmt_execute($stmt)) {


                /* LOG */

                $id_user =
                    (int)$_SESSION['id_user'];

                $aktivitas =
                    "Mengubah data kendaraan " .
                    $plat_nomor;

                $stmtLog = mysqli_prepare(
                    $koneksi,
                    "INSERT INTO tb_log_aktivitas
                    (
                        id_user,
                        aktivitas
                    )
                    VALUES (?, ?)"
                );

                mysqli_stmt_bind_param(
                    $stmtLog,
                    "is",
                    $id_user,
                    $aktivitas
                );

                mysqli_stmt_execute($stmtLog);


                header("Location: index.php");
                exit;

            } else {

                $error =
                    "Gagal mengubah data: " .
                    mysqli_error($koneksi);

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Edit Kendaraan - Parkir Mita</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, sans-serif;
}

.form-container {
    width: 600px;
    max-width: 95%;
    margin: 40px auto;
}

.form-card {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,.08);
}

h1 {
    margin-top: 0;
    color: #1e3a8a;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 7px;
}

.error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border-radius: 7px;
    border: none;
    text-decoration: none;
    cursor: pointer;
}

.btn-simpan {
    background: #2563eb;
    color: white;
}

.btn-kembali {
    background: #6b7280;
    color: white;
}

</style>

</head>

<body>

<div class="form-container">

<div class="form-card">

<h1>
✏️ Edit Kendaraan
</h1>


<?php if ($error !== "") { ?>

<div class="error">

<?php
echo htmlspecialchars($error);
?>

</div>

<?php } ?>


<form method="POST">


<div class="form-group">

<label>
Plat Nomor
</label>

<input
type="text"
name="plat_nomor"
maxlength="15"
value="<?php
echo htmlspecialchars(
    $_POST['plat_nomor']
    ?? $data['plat_nomor']
);
?>"
required
>

</div>


<div class="form-group">

<label>
Jenis Kendaraan
</label>

<select
name="jenis_kendaraan"
required
>

<option value="">
-- Pilih Jenis --
</option>

<option
value="Motor"
<?php
if (
    ($_POST['jenis_kendaraan']
    ?? $data['jenis_kendaraan'])
    == 'Motor'
) echo 'selected';
?>
>
Motor
</option>

<option
value="Mobil"
<?php
if (
    ($_POST['jenis_kendaraan']
    ?? $data['jenis_kendaraan'])
    == 'Mobil'
) echo 'selected';
?>
>
Mobil
</option>

<option
value="Lainnya"
<?php
if (
    ($_POST['jenis_kendaraan']
    ?? $data['jenis_kendaraan'])
    == 'Lainnya'
) echo 'selected';
?>
>
Lainnya
</option>

</select>

</div>


<div class="form-group">

<label>
Warna
</label>

<input
type="text"
name="warna"
maxlength="20"
value="<?php
echo htmlspecialchars(
    $_POST['warna']
    ?? $data['warna']
);
?>"
required
>

</div>


<div class="form-group">

<label>
Nama Pemilik
</label>

<input
type="text"
name="pemilik"
maxlength="100"
value="<?php
echo htmlspecialchars(
    $_POST['pemilik']
    ?? $data['pemilik']
);
?>"
required
>

</div>


<button
type="submit"
class="btn btn-simpan"
>
💾 Simpan Perubahan
</button>


<a
href="index.php"
class="btn btn-kembali"
>
↩ Kembali
</a>

</form>

</div>

</div>

</body>

</html>