<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

$query = mysqli_query(
    $koneksi,
    "SELECT
        k.id_kendaraan,
        k.plat_nomor,
        k.jenis_kendaraan,
        k.warna,
        k.pemilik,
        u.nama_lengkap
     FROM tb_kendaraan k
     LEFT JOIN tb_user u
        ON k.id_user = u.id_user
     ORDER BY k.id_kendaraan DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Data Kendaraan - Parkir Mita</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
    color: #333;
}

/* SIDEBAR */

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 240px;
    height: 100vh;
    background: #1e3a8a;
    color: white;
    padding-top: 20px;
}

.logo {
    text-align: center;
    padding: 15px;
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    padding: 13px 20px;
    color: white;
    text-decoration: none;
}

.sidebar a:hover {
    background: #2563eb;
}

.sidebar a.active {
    background: #2563eb;
}

/* CONTENT */

.content {
    margin-left: 240px;
    padding: 30px;
}

.header {
    background: white;
    padding: 20px;
    border-radius: 10px;
    margin-bottom: 25px;
}

.header h1 {
    margin: 0;
    color: #1e3a8a;
}

.header p {
    margin-bottom: 0;
    color: #666;
}

/* CARD */

.card {
    background: white;
    border-radius: 10px;
    padding: 25px;
    box-shadow: 0 2px 8px rgba(0,0,0,.08);
}

/* BUTTON */

.btn {
    display: inline-block;
    padding: 10px 15px;
    border-radius: 6px;
    text-decoration: none;
    border: none;
    cursor: pointer;
}

.btn-tambah {
    background: #16a34a;
    color: white;
    margin-bottom: 20px;
}

.btn-edit {
    background: #f59e0b;
    color: white;
}

.btn-hapus {
    background: #dc2626;
    color: white;
}

.btn:hover {
    opacity: .85;
}

/* TABLE */

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

thead {
    background: #1e40af;
    color: white;
}

th,
td {
    padding: 13px;
    border-bottom: 1px solid #ddd;
    text-align: left;
}

tbody tr:hover {
    background: #f8fafc;
}

/* BADGE */

.badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.motor {
    background: #dbeafe;
    color: #1d4ed8;
}

.mobil {
    background: #dcfce7;
    color: #15803d;
}

.lainnya {
    background: #f3e8ff;
    color: #7e22ce;
}

.empty {
    text-align: center;
    padding: 30px;
    color: #777;
}

@media (max-width: 768px) {

    .sidebar {
        width: 200px;
    }

    .content {
        margin-left: 200px;
        padding: 15px;
    }

}

</style>

</head>

<body>


<!-- SIDEBAR -->

<div class="sidebar">

    <div class="logo">
        🚗 PARKIR MITA
    </div>

    <a href="../dashboard/index.php">
        🏠 Dashboard
    </a>

    <a href="index.php" class="active">
        🚙 Data Kendaraan
    </a>

    <a href="../transaksi/masuk.php">
        🟢 Kendaraan Masuk
    </a>

    <a href="../transaksi/keluar.php">
        🔴 Kendaraan Keluar
    </a>

    <a href="../transaksi/riwayat.php">
        📋 Riwayat
    </a>

    <a href="../area/index.php">
        📍 Area Parkir
    </a>

    <a href="../tarif/index.php">
        💰 Tarif
    </a>

    <a href="../laporan/index.php">
        📊 Laporan
    </a>

    <?php if ($_SESSION['role'] == 'admin') { ?>

        <a href="../user/index.php">
            👤 Data User
        </a>

        <a href="../log/index.php">
            📝 Log Aktivitas
        </a>

    <?php } ?>

    <a href="../auth/logout.php">
        🚪 Logout
    </a>

</div>


<!-- CONTENT -->

<div class="content">

    <div class="header">

        <h1>
            🚙 Data Kendaraan
        </h1>

        <p>
            Kelola data kendaraan yang terdaftar di sistem parkir.
        </p>

    </div>


    <div class="card">

        <a
            href="tambah.php"
            class="btn btn-tambah"
        >
            + Tambah Kendaraan
        </a>


        <div class="table-container">

            <table>

                <thead>

                    <tr>

                        <th>No</th>

                        <th>Plat Nomor</th>

                        <th>Jenis Kendaraan</th>

                        <th>Warna</th>

                        <th>Pemilik</th>

                        <th>Input Oleh</th>

                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while ($row = mysqli_fetch_assoc($query)) {

                        $jenis = strtolower(
                            $row['jenis_kendaraan']
                        );

                        ?>

                        <tr>

                            <td>
                                <?php echo $no++; ?>
                            </td>

                            <td>
                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $row['plat_nomor']
                                    );
                                    ?>
                                </strong>
                            </td>

                            <td>

                                <?php

                                $class = "lainnya";

                                if ($jenis == "motor") {
                                    $class = "motor";
                                }

                                if ($jenis == "mobil") {
                                    $class = "mobil";
                                }

                                ?>

                                <span class="badge <?php echo $class; ?>">

                                    <?php
                                    echo htmlspecialchars(
                                        $row['jenis_kendaraan']
                                    );
                                    ?>

                                </span>

                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $row['warna']
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $row['pemilik']
                                );
                                ?>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $row['nama_lengkap'] ?? '-'
                                );
                                ?>
                            </td>

                            <td>

                                <a
                                    href="edit.php?id=<?php echo $row['id_kendaraan']; ?>"
                                    class="btn btn-edit"
                                >
                                    ✏️ Edit
                                </a>

                                <a
                                    href="hapus.php?id=<?php echo $row['id_kendaraan']; ?>"
                                    class="btn btn-hapus"
                                    onclick="return confirm('Apakah kamu yakin ingin menghapus kendaraan ini?')"
                                >
                                    🗑️ Hapus
                                </a>

                            </td>

                        </tr>

                        <?php

                    }

                } else {

                    ?>

                    <tr>

                        <td
                            colspan="7"
                            class="empty"
                        >
                            Belum ada data kendaraan.
                        </td>

                    </tr>

                    <?php

                }

                ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>

</html>