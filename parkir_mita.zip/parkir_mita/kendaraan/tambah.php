<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $plat_nomor = strtoupper(
        trim($_POST['plat_nomor'] ?? "")
    );

    $jenis_kendaraan = trim(
        $_POST['jenis_kendaraan'] ?? ""
    );

    $warna = trim(
        $_POST['warna'] ?? ""
    );

    $pemilik = trim(
        $_POST['pemilik'] ?? ""
    );

    $id_user = (int)$_SESSION['id_user'];


    /* VALIDASI */

    if (
        $plat_nomor === "" ||
        $jenis_kendaraan === "" ||
        $warna === "" ||
        $pemilik === ""
    ) {

        $error = "Semua data wajib diisi.";

    } else {


        /* CEK PLAT */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id_kendaraan
             FROM tb_kendaraan
             WHERE plat_nomor = ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "s",
            $plat_nomor
        );

        mysqli_stmt_execute($stmt);

        $result = mysqli_stmt_get_result($stmt);


        if (mysqli_num_rows($result) > 0) {

            $error = "Plat nomor tersebut sudah terdaftar.";

        } else {


            /* SIMPAN */

            $stmt = mysqli_prepare(
                $koneksi,
                "INSERT INTO tb_kendaraan
                (
                    plat_nomor,
                    jenis_kendaraan,
                    warna,
                    pemilik,
                    id_user
                )
                VALUES (?, ?, ?, ?, ?)"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "ssssi",
                $plat_nomor,
                $jenis_kendaraan,
                $warna,
                $pemilik,
                $id_user
            );


            if (mysqli_stmt_execute($stmt)) {


                /* LOG */

                $aktivitas =
                    "Menambahkan kendaraan " .
                    $plat_nomor;

                $stmtLog = mysqli_prepare(
                    $koneksi,
                    "INSERT INTO tb_log_aktivitas
                    (
                        id_user,
                        aktivitas
                    )
                    VALUES (?, ?)"
                );

                mysqli_stmt_bind_param(
                    $stmtLog,
                    "is",
                    $id_user,
                    $aktivitas
                );

                mysqli_stmt_execute($stmtLog);


                header("Location: index.php");
                exit;

            } else {

                $error =
                    "Gagal menyimpan data: " .
                    mysqli_error($koneksi);

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Tambah Kendaraan - Parkir Mita</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #f4f6f9;
    font-family: Arial, sans-serif;
}

.form-container {
    width: 600px;
    max-width: 95%;
    margin: 40px auto;
}

.form-card {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,.08);
}

h1 {
    color: #1e3a8a;
    margin-top: 0;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 8px;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 7px;
    font-size: 15px;
}

input:focus,
select:focus {
    outline: none;
    border-color: #2563eb;
}

.error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border: none;
    border-radius: 7px;
    text-decoration: none;
    cursor: pointer;
    font-size: 14px;
}

.btn-simpan {
    background: #16a34a;
    color: white;
}

.btn-kembali {
    background: #6b7280;
    color: white;
}

</style>

</head>

<body>

<div class="form-container">

    <div class="form-card">

        <h1>
            🚙 Tambah Kendaraan
        </h1>

        <p>
            Masukkan data kendaraan baru.
        </p>


        <?php if ($error !== "") { ?>

            <div class="error">

                <?php
                echo htmlspecialchars($error);
                ?>

            </div>

        <?php } ?>


        <form method="POST">


            <div class="form-group">

                <label>
                    Plat Nomor
                </label>

                <input
                    type="text"
                    name="plat_nomor"
                    placeholder="Contoh: N 1234 AB"
                    maxlength="15"
                    value="<?php
                        echo htmlspecialchars(
                            $_POST['plat_nomor'] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Jenis Kendaraan
                </label>

                <select
                    name="jenis_kendaraan"
                    required
                >

                    <option value="">
                        -- Pilih Jenis --
                    </option>

                    <option value="Motor">
                        Motor
                    </option>

                    <option value="Mobil">
                        Mobil
                    </option>

                    <option value="Lainnya">
                        Lainnya
                    </option>

                </select>

            </div>


            <div class="form-group">

                <label>
                    Warna
                </label>

                <input
                    type="text"
                    name="warna"
                    placeholder="Contoh: Hitam"
                    maxlength="20"
                    value="<?php
                        echo htmlspecialchars(
                            $_POST['warna'] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <div class="form-group">

                <label>
                    Nama Pemilik
                </label>

                <input
                    type="text"
                    name="pemilik"
                    placeholder="Masukkan nama pemilik"
                    maxlength="100"
                    value="<?php
                        echo htmlspecialchars(
                            $_POST['pemilik'] ?? ''
                        );
                    ?>"
                    required
                >

            </div>


            <button
                type="submit"
                class="btn btn-simpan"
            >
                💾 Simpan Kendaraan
            </button>


            <a
                href="index.php"
                class="btn btn-kembali"
            >
                ↩ Kembali
            </a>

        </form>

    </div>

</div>

</body>

</html>