<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard/index.php");
    exit;
}

$query = mysqli_query(
    $koneksi,
    "SELECT
        id_user,
        nama_lengkap,
        username,
        role,
        status_aktif,
        last_login
     FROM tb_user
     ORDER BY id_user DESC"
);

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Data User - Parkir Mita</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
}

.sidebar {
    position: fixed;
    left: 0;
    top: 0;
    width: 240px;
    height: 100vh;
    background: #1e3a8a;
    color: white;
}

.logo {
    padding: 25px 15px;
    text-align: center;
    font-weight: bold;
    font-size: 20px;
    border-bottom: 1px solid rgba(255,255,255,.15);
}

.user-info {
    margin: 15px;
    padding: 15px;
    background: rgba(255,255,255,.1);
    border-radius: 8px;
}

.sidebar a {
    display: block;
    padding: 13px 20px;
    color: white;
    text-decoration: none;
    font-size: 14px;
}

.sidebar a:hover {
    background: #2563eb;
}

.sidebar a.active {
    background: #2563eb;
}

.content {
    margin-left: 240px;
    padding: 30px;
}

.header {
    background: white;
    padding: 22px;
    border-radius: 10px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.header h1 {
    margin: 0;
    color: #1e3a8a;
}

.header p {
    margin-bottom: 0;
    color: #777;
}

.card {
    background: white;
    padding: 25px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,.06);
}

.btn {
    display: inline-block;
    padding: 10px 15px;
    border-radius: 6px;
    text-decoration: none;
    border: none;
    cursor: pointer;
    font-size: 13px;
}

.btn-tambah {
    background: #16a34a;
    color: white;
    margin-bottom: 20px;
}

.btn-edit {
    background: #f59e0b;
    color: white;
}

.btn-hapus {
    background: #dc2626;
    color: white;
}

.btn:hover {
    opacity: .85;
}

.table-container {
    overflow-x: auto;
}

table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #1e40af;
    color: white;
    padding: 13px;
    text-align: left;
}

td {
    padding: 13px;
    border-bottom: 1px solid #ddd;
}

tbody tr:hover {
    background: #f8fafc;
}

.badge {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.admin {
    background: #ede9fe;
    color: #6d28d9;
}

.petugas {
    background: #dbeafe;
    color: #1d4ed8;
}

.owner {
    background: #dcfce7;
    color: #15803d;
}

.aktif {
    background: #dcfce7;
    color: #166534;
}

.nonaktif {
    background: #fee2e2;
    color: #991b1b;
}

.empty {
    text-align: center;
    padding: 30px;
    color: #777;
}

</style>

</head>

<body>


<div class="sidebar">

    <div class="logo">
        🚗 PARKIR MITA
    </div>

    <div class="user-info">

        👤

        <strong>
            <?php
            echo htmlspecialchars(
                $_SESSION['nama_lengkap']
            );
            ?>
        </strong>

        <br>

        <small>
            <?php
            echo htmlspecialchars(
                $_SESSION['role']
            );
            ?>
        </small>

    </div>


    <a href="../dashboard/index.php">
        🏠 Dashboard
    </a>

    <a href="../kendaraan/index.php">
        🚙 Data Kendaraan
    </a>

    <a href="../transaksi/masuk.php">
        🟢 Kendaraan Masuk
    </a>

    <a href="../transaksi/keluar.php">
        🔴 Kendaraan Keluar
    </a>

    <a href="../transaksi/riwayat.php">
        📋 Riwayat Transaksi
    </a>

    <a href="../area/index.php">
        📍 Area Parkir
    </a>

    <a href="../tarif/index.php">
        💰 Tarif Parkir
    </a>

    <a href="../laporan/index.php">
        📊 Laporan
    </a>

    <a
        href="index.php"
        class="active"
    >
        👤 Data User
    </a>

    <a href="../log/index.php">
        📝 Log Aktivitas
    </a>

    <a href="../auth/logout.php">
        🚪 Logout
    </a>

</div>


<div class="content">

    <div class="header">

        <h1>
            👤 Data User
        </h1>

        <p>
            Kelola pengguna sistem parkir.
        </p>

    </div>


    <div class="card">

        <a
            href="tambah.php"
            class="btn btn-tambah"
        >
            + Tambah User
        </a>


        <div class="table-container">

            <table>

                <thead>

                    <tr>

                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Login Terakhir</th>
                        <th>Aksi</th>

                    </tr>

                </thead>


                <tbody>

                <?php

                $no = 1;

                if (mysqli_num_rows($query) > 0) {

                    while (
                        $row =
                        mysqli_fetch_assoc($query)
                    ) {

                        $role =
                            strtolower(
                                $row['role']
                            );

                        ?>

                        <tr>

                            <td>
                                <?php echo $no++; ?>
                            </td>

                            <td>
                                <strong>
                                    <?php
                                    echo htmlspecialchars(
                                        $row['nama_lengkap']
                                    );
                                    ?>
                                </strong>
                            </td>

                            <td>
                                <?php
                                echo htmlspecialchars(
                                    $row['username']
                                );
                                ?>
                            </td>

                            <td>

                                <span
                                    class="badge
                                    <?php echo $role; ?>"
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        ucfirst(
                                            $row['role']
                                        )
                                    );
                                    ?>

                                </span>

                            </td>

                            <td>

                                <?php if (
                                    $row['status_aktif'] == 1
                                ) { ?>

                                    <span
                                        class="badge aktif"
                                    >
                                        Aktif
                                    </span>

                                <?php } else { ?>

                                    <span
                                        class="badge nonaktif"
                                    >
                                        Nonaktif
                                    </span>

                                <?php } ?>

                            </td>

                            <td>

                                <?php

                                if (
                                    !empty(
                                        $row['last_login']
                                    )
                                ) {

                                    echo date(
                                        "d/m/Y H:i",
                                        strtotime(
                                            $row['last_login']
                                        )
                                    );

                                } else {

                                    echo "Belum login";

                                }

                                ?>

                            </td>

                            <td>

                                <a
                                    href="edit.php?id=<?php echo $row['id_user']; ?>"
                                    class="btn btn-edit"
                                >
                                    ✏️ Edit
                                </a>

                                <?php

                                if (
                                    $row['id_user']
                                    != $_SESSION['id_user']
                                ) {

                                ?>

                                <a
                                    href="hapus.php?id=<?php echo $row['id_user']; ?>"
                                    class="btn btn-hapus"
                                    onclick="return confirm('Yakin ingin menghapus user ini?')"
                                >
                                    🗑️ Hapus
                                </a>

                                <?php } ?>

                            </td>

                        </tr>

                        <?php

                    }

                } else {

                    ?>

                    <tr>

                        <td
                            colspan="7"
                            class="empty"
                        >
                            Belum ada data user.
                        </td>

                    </tr>

                    <?php

                }

                ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>

</html>