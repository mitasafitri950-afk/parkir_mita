<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard/index.php");
    exit;
}

$id = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;


/*
|--------------------------------------------------------------------------
| CEK ID
|--------------------------------------------------------------------------
*/

if ($id <= 0) {
    header("Location: index.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| JANGAN HAPUS DIRI SENDIRI
|--------------------------------------------------------------------------
*/

if ($id == $_SESSION['id_user']) {

    echo "

    <!DOCTYPE html>

    <html lang='id'>

    <head>

    <meta charset='UTF-8'>

    <title>Gagal</title>

    <style>

    body {
        font-family: Arial;
        background: #f4f6f9;
    }

    .box {
        width: 500px;
        max-width: 90%;
        margin: 100px auto;
        background: white;
        padding: 30px;
        border-radius: 10px;
        text-align: center;
    }

    .error {
        background: #fee2e2;
        color: #991b1b;
        padding: 15px;
        border-radius: 7px;
        margin-bottom: 20px;
    }

    a {
        display: inline-block;
        padding: 10px 20px;
        background: #2563eb;
        color: white;
        text-decoration: none;
        border-radius: 7px;
    }

    </style>

    </head>

    <body>

    <div class='box'>

        <h2>⚠️ Tidak Dapat Menghapus</h2>

        <div class='error'>

            Kamu tidak dapat menghapus
            akun yang sedang digunakan.

        </div>

        <a href='index.php'>
            Kembali
        </a>

    </div>

    </body>

    </html>

    ";

    exit;
}


/*
|--------------------------------------------------------------------------
| AMBIL USER
|--------------------------------------------------------------------------
*/

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT
        id_user,
        username
     FROM tb_user
     WHERE id_user = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$result =
    mysqli_stmt_get_result($stmt);


if (
    mysqli_num_rows($result) !== 1
) {

    header("Location: index.php");
    exit;

}

$user =
    mysqli_fetch_assoc($result);

$username =
    $user['username'];


/*
|--------------------------------------------------------------------------
| CEK DATA YANG TERKAIT
|--------------------------------------------------------------------------
|
| Jika user sudah dipakai untuk kendaraan atau transaksi,
| lebih aman menonaktifkan akun daripada menghapusnya.
|
*/


$stmt = mysqli_prepare(
    $koneksi,
    "SELECT id_kendaraan
     FROM tb_kendaraan
     WHERE id_user = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$kendaraan =
    mysqli_stmt_get_result($stmt);


if (
    mysqli_num_rows($kendaraan) > 0
) {

    echo "

    <!DOCTYPE html>

    <html lang='id'>

    <head>

    <meta charset='UTF-8'>

    <title>User Tidak Dapat Dihapus</title>

    <style>

    body {
        font-family: Arial;
        background: #f4f6f9;
    }

    .box {
        width: 520px;
        max-width: 90%;
        margin: 100px auto;
        background: white;
        padding: 30px;
        border-radius: 10px;
        text-align: center;
    }

    .warning {
        background: #fef3c7;
        color: #92400e;
        padding: 15px;
        border-radius: 7px;
        margin-bottom: 20px;
    }

    a {
        display: inline-block;
        padding: 10px 20px;
        background: #2563eb;
        color: white;
        text-decoration: none;
        border-radius: 7px;
    }

    </style>

    </head>

    <body>

    <div class='box'>

        <h2>⚠️ User Tidak Dapat Dihapus</h2>

        <div class='warning'>

            User <b>" .
            htmlspecialchars($username) .
            "</b>
            masih memiliki data kendaraan.

            <br><br>

            Sebaiknya ubah status user menjadi
            <b>Nonaktif</b> daripada menghapusnya.

        </div>

        <a href='index.php'>
            Kembali
        </a>

    </div>

    </body>

    </html>

    ";

    exit;
}


/*
|--------------------------------------------------------------------------
| HAPUS USER
|--------------------------------------------------------------------------
*/

$stmt = mysqli_prepare(
    $koneksi,
    "DELETE FROM tb_user
     WHERE id_user = ?"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);


if (
    mysqli_stmt_execute($stmt)
) {


    /*
     * CATAT LOG SEBELUM DATA USER HILANG
     */

    $id_admin =
        (int)$_SESSION['id_user'];

    $aktivitas =
        "Menghapus user " .
        $username;

    $stmtLog =
        mysqli_prepare(
            $koneksi,
            "INSERT INTO tb_log_aktivitas
            (
                id_user,
                aktivitas
            )
            VALUES (?, ?)"
        );

    mysqli_stmt_bind_param(
        $stmtLog,
        "is",
        $id_admin,
        $aktivitas
    );

    mysqli_stmt_execute($stmtLog);

}


header("Location: index.php");
exit;

?>