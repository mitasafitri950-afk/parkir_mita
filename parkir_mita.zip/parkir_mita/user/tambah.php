<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard/index.php");
    exit;
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nama_lengkap = trim(
        $_POST['nama_lengkap'] ?? ""
    );

    $username = trim(
        $_POST['username'] ?? ""
    );

    $password = trim(
        $_POST['password'] ?? ""
    );

    $role = trim(
        $_POST['role'] ?? ""
    );

    $status_aktif = isset(
        $_POST['status_aktif']
    ) ? 1 : 0;


    if (
        $nama_lengkap === "" ||
        $username === "" ||
        $password === "" ||
        $role === ""
    ) {

        $error = "Semua data wajib diisi.";

    } elseif (
        !in_array(
            $role,
            ['admin', 'petugas', 'owner']
        )
    ) {

        $error = "Role tidak valid.";

    } else {


        /* CEK USERNAME */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id_user
             FROM tb_user
             WHERE username = ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "s",
            $username
        );

        mysqli_stmt_execute($stmt);

        $result =
            mysqli_stmt_get_result($stmt);


        if (
            mysqli_num_rows($result) > 0
        ) {

            $error =
                "Username sudah digunakan.";

        } else {


            /*
             * Password dibuat hash agar lebih aman.
             */

            $passwordHash =
                password_hash(
                    $password,
                    PASSWORD_DEFAULT
                );


            $stmt = mysqli_prepare(
                $koneksi,
                "INSERT INTO tb_user
                (
                    nama_lengkap,
                    username,
                    password,
                    role,
                    status_aktif
                )
                VALUES (?, ?, ?, ?, ?)"
            );

            mysqli_stmt_bind_param(
                $stmt,
                "ssssi",
                $nama_lengkap,
                $username,
                $passwordHash,
                $role,
                $status_aktif
            );


            if (
                mysqli_stmt_execute($stmt)
            ) {

                $id_user =
                    (int)$_SESSION['id_user'];

                $aktivitas =
                    "Menambahkan user " .
                    $username;

                $stmtLog =
                    mysqli_prepare(
                        $koneksi,
                        "INSERT INTO tb_log_aktivitas
                        (
                            id_user,
                            aktivitas
                        )
                        VALUES (?, ?)"
                    );

                mysqli_stmt_bind_param(
                    $stmtLog,
                    "is",
                    $id_user,
                    $aktivitas
                );

                mysqli_stmt_execute(
                    $stmtLog
                );

                header(
                    "Location: index.php"
                );

                exit;

            } else {

                $error =
                    "Gagal menambahkan user: " .
                    mysqli_error($koneksi);

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>
Tambah User - Parkir Mita
</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
}

.container {
    width: 600px;
    max-width: 95%;
    margin: 40px auto;
}

.card {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,.08);
}

h1 {
    color: #1e3a8a;
    margin-top: 0;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 7px;
    font-size: 14px;
}

input:focus,
select:focus {
    outline: none;
    border-color: #2563eb;
}

.checkbox {
    display: flex;
    align-items: center;
    gap: 8px;
}

.checkbox input {
    width: auto;
}

.error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border-radius: 7px;
    border: none;
    text-decoration: none;
    cursor: pointer;
}

.btn-simpan {
    background: #16a34a;
    color: white;
}

.btn-kembali {
    background: #6b7280;
    color: white;
}

</style>

</head>

<body>


<div class="container">

<div class="card">

<h1>
👤 Tambah User
</h1>

<p>
Buat akun pengguna baru.
</p>


<?php if ($error !== "") { ?>

<div class="error">

<?php
echo htmlspecialchars($error);
?>

</div>

<?php } ?>


<form method="POST">


<div class="form-group">

<label>
Nama Lengkap
</label>

<input
    type="text"
    name="nama_lengkap"
    maxlength="100"
    value="<?php
        echo htmlspecialchars(
            $_POST['nama_lengkap'] ?? ''
        );
    ?>"
    required
>

</div>


<div class="form-group">

<label>
Username
</label>

<input
    type="text"
    name="username"
    maxlength="50"
    value="<?php
        echo htmlspecialchars(
            $_POST['username'] ?? ''
        );
    ?>"
    required
>

</div>


<div class="form-group">

<label>
Password
</label>

<input
    type="password"
    name="password"
    minlength="6"
    required
>

</div>


<div class="form-group">

<label>
Role
</label>

<select
    name="role"
    required
>

<option value="">
-- Pilih Role --
</option>

<option value="admin">
Admin
</option>

<option value="petugas">
Petugas
</option>

<option value="owner">
Owner
</option>

</select>

</div>


<div class="form-group">

<label class="checkbox">

<input
    type="checkbox"
    name="status_aktif"
    value="1"
    checked
>

Akun Aktif

</label>

</div>


<button
    type="submit"
    class="btn btn-simpan"
>
💾 Simpan User
</button>


<a
    href="index.php"
    class="btn btn-kembali"
>
↩ Kembali
</a>


</form>

</div>

</div>

</body>

</html>