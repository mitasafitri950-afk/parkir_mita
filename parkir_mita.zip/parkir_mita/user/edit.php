<?php

require_once "../config/auth.php";
require_once "../config/koneksi.php";

if ($_SESSION['role'] !== 'admin') {
    header("Location: ../dashboard/index.php");
    exit;
}

$id = isset($_GET['id'])
    ? (int)$_GET['id']
    : 0;

if ($id <= 0) {
    header("Location: index.php");
    exit;
}


/* AMBIL DATA */

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT *
     FROM tb_user
     WHERE id_user = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $id
);

mysqli_stmt_execute($stmt);

$result =
    mysqli_stmt_get_result($stmt);


if (
    mysqli_num_rows($result) !== 1
) {

    header("Location: index.php");
    exit;

}

$data =
    mysqli_fetch_assoc($result);

$error = "";


/* UPDATE */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nama_lengkap = trim(
        $_POST['nama_lengkap'] ?? ""
    );

    $username = trim(
        $_POST['username'] ?? ""
    );

    $password = trim(
        $_POST['password'] ?? ""
    );

    $role = trim(
        $_POST['role'] ?? ""
    );

    $status_aktif = isset(
        $_POST['status_aktif']
    ) ? 1 : 0;


    if (
        $nama_lengkap === "" ||
        $username === "" ||
        $role === ""
    ) {

        $error =
            "Nama, username, dan role wajib diisi.";

    } elseif (
        !in_array(
            $role,
            ['admin', 'petugas', 'owner']
        )
    ) {

        $error =
            "Role tidak valid.";

    } else {


        /* CEK USERNAME */

        $stmt = mysqli_prepare(
            $koneksi,
            "SELECT id_user
             FROM tb_user
             WHERE username = ?
             AND id_user != ?
             LIMIT 1"
        );

        mysqli_stmt_bind_param(
            $stmt,
            "si",
            $username,
            $id
        );

        mysqli_stmt_execute($stmt);

        $cek =
            mysqli_stmt_get_result($stmt);


        if (
            mysqli_num_rows($cek) > 0
        ) {

            $error =
                "Username sudah digunakan.";

        } else {


            /*
             * Kalau password kosong,
             * password lama tetap digunakan.
             */

            if ($password !== "") {

                $passwordHash =
                    password_hash(
                        $password,
                        PASSWORD_DEFAULT
                    );

                $stmt = mysqli_prepare(
                    $koneksi,
                    "UPDATE tb_user
                     SET
                        nama_lengkap = ?,
                        username = ?,
                        password = ?,
                        role = ?,
                        status_aktif = ?
                     WHERE id_user = ?"
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    "ssssii",
                    $nama_lengkap,
                    $username,
                    $passwordHash,
                    $role,
                    $status_aktif,
                    $id
                );

            } else {

                $stmt = mysqli_prepare(
                    $koneksi,
                    "UPDATE tb_user
                     SET
                        nama_lengkap = ?,
                        username = ?,
                        role = ?,
                        status_aktif = ?
                     WHERE id_user = ?"
                );

                mysqli_stmt_bind_param(
                    $stmt,
                    "sssii",
                    $nama_lengkap,
                    $username,
                    $role,
                    $status_aktif,
                    $id
                );

            }


            if (
                mysqli_stmt_execute($stmt)
            ) {


                /* LOG */

                $id_user =
                    (int)$_SESSION['id_user'];

                $aktivitas =
                    "Mengubah data user " .
                    $username;

                $stmtLog =
                    mysqli_prepare(
                        $koneksi,
                        "INSERT INTO tb_log_aktivitas
                        (
                            id_user,
                            aktivitas
                        )
                        VALUES (?, ?)"
                    );

                mysqli_stmt_bind_param(
                    $stmtLog,
                    "is",
                    $id_user,
                    $aktivitas
                );

                mysqli_stmt_execute(
                    $stmtLog
                );


                /*
                 * Jika admin mengedit dirinya sendiri,
                 * session diperbarui.
                 */

                if (
                    $id ==
                    $_SESSION['id_user']
                ) {

                    $_SESSION['nama_lengkap'] =
                        $nama_lengkap;

                    $_SESSION['username'] =
                        $username;

                    $_SESSION['role'] =
                        $role;

                }


                header(
                    "Location: index.php"
                );

                exit;

            } else {

                $error =
                    "Gagal mengubah user: " .
                    mysqli_error($koneksi);

            }

        }

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1"
>

<title>
Edit User - Parkir Mita
</title>

<style>

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #f4f6f9;
}

.container {
    width: 600px;
    max-width: 95%;
    margin: 40px auto;
}

.card {
    background: white;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,.08);
}

h1 {
    color: #1e3a8a;
    margin-top: 0;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    margin-bottom: 8px;
    font-weight: bold;
}

input,
select {
    width: 100%;
    padding: 12px;
    border: 1px solid #d1d5db;
    border-radius: 7px;
}

.checkbox {
    display: flex;
    align-items: center;
    gap: 8px;
}

.checkbox input {
    width: auto;
}

.error {
    background: #fee2e2;
    color: #991b1b;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 20px;
}

.info {
    background: #eff6ff;
    color: #1e40af;
    padding: 12px;
    border-radius: 7px;
    margin-bottom: 20px;
    font-size: 13px;
}

.btn {
    display: inline-block;
    padding: 11px 18px;
    border-radius: 7px;
    border: none;
    text-decoration: none;
    cursor: pointer;
}

.btn-simpan {
    background: #2563eb;
    color: white;
}

.btn-kembali {
    background: #6b7280;
    color: white;
}

</style>

</head>

<body>


<div class="container">

<div class="card">

<h1>
✏️ Edit User
</h1>


<?php if ($error !== "") { ?>

<div class="error">

<?php
echo htmlspecialchars($error);
?>

</div>

<?php } ?>


<div class="info">

Kosongkan password jika tidak ingin
mengubah password user.

</div>


<form method="POST">


<div class="form-group">

<label>
Nama Lengkap
</label>

<input
    type="text"
    name="nama_lengkap"
    maxlength="100"
    value="<?php
        echo htmlspecialchars(
            $_POST['nama_lengkap']
            ?? $data['nama_lengkap']
        );
    ?>"
    required
>

</div>


<div class="form-group">

<label>
Username
</label>

<input
    type="text"
    name="username"
    maxlength="50"
    value="<?php
        echo htmlspecialchars(
            $_POST['username']
            ?? $data['username']
        );
    ?>"
    required
>

</div>


<div class="form-group">

<label>
Password Baru
</label>

<input
    type="password"
    name="password"
    minlength="6"
    placeholder="Kosongkan jika tidak diubah"
>

</div>


<div class="form-group">

<label>
Role
</label>

<select
    name="role"
    required
>

<option
    value="admin"
    <?php
    if (
        ($_POST['role']
        ?? $data['role'])
        == 'admin'
    ) echo 'selected';
    ?>
>
Admin
</option>

<option
    value="petugas"
    <?php
    if (
        ($_POST['role']
        ?? $data['role'])
        == 'petugas'
    ) echo 'selected';
    ?>
>
Petugas
</option>

<option
    value="owner"
    <?php
    if (
        ($_POST['role']
        ?? $data['role'])
        == 'owner'
    ) echo 'selected';
    ?>
>
Owner
</option>

</select>

</div>


<div class="form-group">

<label class="checkbox">

<input
    type="checkbox"
    name="status_aktif"
    value="1"
    <?php

    $status =
        $_POST['status_aktif']
        ?? $data['status_aktif'];

    if ($status == 1) {
        echo "checked";
    }

    ?>
>

Akun Aktif

</label>

</div>


<button
    type="submit"
    class="btn btn-simpan"
>
💾 Simpan Perubahan
</button>


<a
    href="index.php"
    class="btn btn-kembali"
>
↩ Kembali
</a>


</form>

</div>

</div>

</body>

</html>