<?php

session_start();

require_once dirname(__DIR__) . "/config/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit;
}

$username = trim($_POST['username'] ?? "");
$password = trim($_POST['password'] ?? "");

if ($username === "" || $password === "") {
    header("Location: login.php?pesan=kosong");
    exit;
}

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT
        id_user,
        nama_lengkap,
        username,
        password,
        role,
        status_aktif
     FROM tb_user
     WHERE username = ?
     LIMIT 1"
);

mysqli_stmt_bind_param(
    $stmt,
    "s",
    $username
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) !== 1) {
    header("Location: login.php?pesan=salah");
    exit;
}

$user = mysqli_fetch_assoc($result);

if ((int)$user['status_aktif'] !== 1) {
    header("Location: login.php?pesan=nonaktif");
    exit;
}

/*
 * Sesuai database yang kamu upload:
 * password masih disimpan sebagai teks biasa.
 */
if ($password !== $user['password']) {
    header("Location: login.php?pesan=salah");
    exit;
}

session_regenerate_id(true);

$_SESSION['login'] = true;
$_SESSION['id_user'] = $user['id_user'];
$_SESSION['nama_lengkap'] = $user['nama_lengkap'];
$_SESSION['username'] = $user['username'];
$_SESSION['role'] = $user['role'];

$id_user = (int)$user['id_user'];

mysqli_query(
    $koneksi,
    "UPDATE tb_user
     SET last_login = NOW()
     WHERE id_user = $id_user"
);

$aktivitas = "Login ke sistem";

$stmtLog = mysqli_prepare(
    $koneksi,
    "INSERT INTO tb_log_aktivitas
    (id_user, aktivitas)
    VALUES (?, ?)"
);

mysqli_stmt_bind_param(
    $stmtLog,
    "is",
    $id_user,
    $aktivitas
);

mysqli_stmt_execute($stmtLog);

header("Location: ../dashboard/index.php");
exit;

?>