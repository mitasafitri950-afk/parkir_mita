<?php

session_start();

if (isset($_SESSION['login']) && $_SESSION['login'] === true) {
    header("Location: ../dashboard/index.php");
    exit;
}

$pesan = "";

if (isset($_GET['pesan'])) {

    switch ($_GET['pesan']) {

        case "kosong":
            $pesan = "Username dan password wajib diisi.";
            break;

        case "salah":
            $pesan = "Username atau password salah.";
            break;

        case "nonaktif":
            $pesan = "Akun kamu tidak aktif.";
            break;
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Login - Parkir Mita</title>

<style>

* {
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    margin: 0;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: linear-gradient(135deg, #1e3a8a, #2563eb);
}

.login-container {
    width: 390px;
    background: white;
    padding: 35px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,.2);
}

.logo {
    text-align: center;
    font-size: 50px;
}

h2 {
    text-align: center;
    margin: 10px 0;
    color: #1e3a8a;
}

.subtitle {
    text-align: center;
    color: #777;
    margin-bottom: 25px;
}

.alert {
    padding: 12px;
    background: #fee2e2;
    color: #991b1b;
    border-radius: 7px;
    margin-bottom: 15px;
}

.form-group {
    margin-bottom: 18px;
}

label {
    display: block;
    margin-bottom: 7px;
    font-weight: bold;
}

input {
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    outline: none;
}

input:focus {
    border-color: #2563eb;
}

button {
    width: 100%;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #2563eb;
    color: white;
    font-size: 16px;
    cursor: pointer;
}

button:hover {
    background: #1d4ed8;
}

.akun {
    margin-top: 20px;
    padding: 12px;
    border-radius: 8px;
    background: #eff6ff;
    color: #1e40af;
    font-size: 13px;
    line-height: 1.7;
}

</style>

</head>

<body>

<div class="login-container">

    <div class="logo">🚗</div>

    <h2>Parkir Mita</h2>

    <div class="subtitle">
        Sistem Informasi Parkir
    </div>

    <?php if ($pesan != "") { ?>

        <div class="alert">
            <?php echo htmlspecialchars($pesan); ?>
        </div>

    <?php } ?>

    <form method="POST" action="proses_login.php">

        <div class="form-group">

            <label>Username</label>

            <input
                type="text"
                name="username"
                placeholder="Masukkan username"
                autocomplete="username"
                required
            >

        </div>

        <div class="form-group">

            <label>Password</label>

            <input
                type="password"
                name="password"
                placeholder="Masukkan password"
                autocomplete="current-password"
                required
            >

        </div>

        <button type="submit">
            🔐 Login
        </button>

    </form>

    <div class="akun">

        <b>Akun yang tersedia:</b><br>

        Admin → admin / admin123<br>
        Petugas → petugas / petugas123<br>
        Owner → owner / owner123

    </div>

</div>

</body>

</html>