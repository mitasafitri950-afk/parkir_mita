<?php

session_start();

require_once "../config/koneksi.php";

if (isset($_SESSION['id_user'])) {

    $id_user = (int)$_SESSION['id_user'];

    $aktivitas = "Logout dari sistem";

    $stmt = mysqli_prepare(
        $koneksi,
        "INSERT INTO tb_log_aktivitas
        (id_user, aktivitas)
        VALUES (?, ?)"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "is",
        $id_user,
        $aktivitas
    );

    mysqli_stmt_execute($stmt);
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {

    $params = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();

header("Location: login.php");
exit;

?>