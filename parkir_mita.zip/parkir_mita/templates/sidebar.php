<?php

$current_page =
    basename($_SERVER['PHP_SELF']);

$current_folder =
    basename(
        dirname($_SERVER['PHP_SELF'])
    );

?>

<div class="sidebar">

    <div class="logo">
        🚗 PARKIR MITA
    </div>


    <!-- USER -->

    <div class="sidebar-user">

        <strong>

            👤

            <?php
            echo htmlspecialchars(
                $_SESSION['nama_lengkap']
                ?? $_SESSION['username']
                ?? 'User'
            );
            ?>

        </strong>

        <small>

            <?php
            echo htmlspecialchars(
                $_SESSION['role']
                ?? 'Petugas'
            );
            ?>

        </small>

    </div>


    <!-- MENU UTAMA -->

    <div class="menu-title">
        Menu Utama
    </div>


    <a
        href="../dashboard/index.php"
        <?php
        if (
            $current_folder == 'dashboard'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        🏠 Dashboard
    </a>


    <a
        href="../kendaraan/index.php"
        <?php
        if (
            $current_folder == 'kendaraan'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        🚙 Data Kendaraan
    </a>


    <a
        href="../transaksi/masuk.php"
        <?php
        if (
            $current_page == 'masuk.php'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        🟢 Kendaraan Masuk
    </a>


    <a
        href="../transaksi/keluar.php"
        <?php
        if (
            $current_page == 'keluar.php'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        🔴 Kendaraan Keluar
    </a>


    <a
        href="../transaksi/riwayat.php"
        <?php
        if (
            $current_page == 'riwayat.php'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        📋 Riwayat Transaksi
    </a>


    <!-- MASTER DATA -->

    <div class="menu-title">
        Master Data
    </div>


    <a
        href="../area/index.php"
        <?php
        if (
            $current_folder == 'area'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        📍 Area Parkir
    </a>


    <a
        href="../tarif/index.php"
        <?php
        if (
            $current_folder == 'tarif'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        💰 Tarif Parkir
    </a>


    <!-- LAPORAN -->

    <div class="menu-title">
        Laporan
    </div>


    <a
        href="../laporan/index.php"
        <?php
        if (
            $current_folder == 'laporan'
        ) {
            echo 'class="active"';
        }
        ?>
    >
        📊 Laporan Parkir
    </a>


    <!-- ADMIN -->

    <?php

    if (
        isset($_SESSION['role']) &&
        $_SESSION['role'] == 'admin'
    ) {

    ?>

        <div class="menu-title">
            Administrator
        </div>


        <a
            href="../user/index.php"
            <?php
            if (
                $current_folder == 'user'
            ) {
                echo 'class="active"';
            }
            ?>
        >
            👤 Data User
        </a>


        <a
            href="../log/index.php"
            <?php
            if (
                $current_folder == 'log'
            ) {
                echo 'class="active"';
            }
            ?>
        >
            📝 Log Aktivitas
        </a>

    <?php

    }

    ?>


    <!-- AKUN -->

    <div class="menu-title">
        Akun
    </div>


    <a
        href="../auth/logout.php"
        onclick="
            return confirm(
                'Yakin ingin logout?'
            );
        "
    >
        🚪 Logout
    </a>

</div>