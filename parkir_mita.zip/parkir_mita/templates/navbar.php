<div class="top-navbar">

    <div class="page-title">

        <h1>

            <?php
            echo htmlspecialchars(
                $page_title
                ?? 'Dashboard'
            );
            ?>

        </h1>

        <p>

            Sistem Informasi
            Parkir Mita

        </p>

    </div>


    <div class="navbar-user">

        <div class="navbar-user-info">

            <strong>

                <?php
                echo htmlspecialchars(
                    $_SESSION['nama_lengkap']
                    ?? $_SESSION['username']
                    ?? 'User'
                );
                ?>

            </strong>

            <small>

                <?php
                echo htmlspecialchars(
                    ucfirst(
                        $_SESSION['role']
                        ?? 'petugas'
                    )
                );
                ?>

            </small>

        </div>


        <a
            href="../auth/logout.php"
            class="logout-btn"
            onclick="
                return confirm(
                    'Yakin ingin logout?'
                );
            "
        >
            🚪 Logout
        </a>

    </div>

</div>