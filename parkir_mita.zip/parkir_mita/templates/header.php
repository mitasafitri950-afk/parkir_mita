<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['login'])) {
    header("Location: ../auth/login.php");
    exit;
}

if (!isset($page_title)) {
    $page_title = "Parkir Mita";
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?php echo htmlspecialchars($page_title); ?>
        | Parkir Mita
    </title>

    <style>

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family:
                Arial,
                Helvetica,
                sans-serif;

            background: #f4f6f9;
            color: #333;
        }

        a {
            text-decoration: none;
        }

        /* SIDEBAR */

        .sidebar {
            position: fixed;

            left: 0;
            top: 0;

            width: 240px;
            height: 100vh;

            background: #1e3a8a;

            color: white;

            overflow-y: auto;

            z-index: 1000;
        }

        .logo {
            padding: 24px 15px;

            text-align: center;

            font-size: 20px;

            font-weight: bold;

            border-bottom:
                1px solid
                rgba(255,255,255,.15);
        }

        .sidebar-user {
            margin: 15px;

            padding: 15px;

            background:
                rgba(255,255,255,.1);

            border-radius: 8px;
        }

        .sidebar-user strong {
            display: block;

            margin-bottom: 5px;
        }

        .sidebar-user small {
            color: #bfdbfe;
        }

        .menu-title {
            padding:
                18px 20px 7px;

            color: #bfdbfe;

            font-size: 11px;

            text-transform: uppercase;
        }

        .sidebar a {
            display: block;

            padding: 13px 20px;

            color: white;

            font-size: 14px;

            transition: .2s;
        }

        .sidebar a:hover {
            background: #2563eb;
        }

        .sidebar a.active {
            background: #2563eb;
        }

        /* CONTENT */

        .main-content {
            margin-left: 240px;

            min-height: 100vh;

            padding: 25px;
        }

        /* TOP NAVBAR */

        .top-navbar {
            display: flex;

            align-items: center;

            justify-content: space-between;

            background: white;

            padding: 18px 22px;

            margin-bottom: 25px;

            border-radius: 10px;

            box-shadow:
                0 2px 8px
                rgba(0,0,0,.06);
        }

        .page-title h1 {
            margin: 0;

            font-size: 24px;

            color: #1e3a8a;
        }

        .page-title p {
            margin:
                5px 0 0;

            color: #777;

            font-size: 13px;
        }

        .navbar-user {
            display: flex;

            align-items: center;

            gap: 12px;
        }

        .navbar-user-info {
            text-align: right;
        }

        .navbar-user-info strong {
            display: block;
        }

        .navbar-user-info small {
            color: #777;
        }

        .logout-btn {
            display: inline-block;

            padding: 9px 13px;

            background: #dc2626;

            color: white;

            border-radius: 7px;

            font-size: 13px;
        }

        .logout-btn:hover {
            background: #b91c1c;
        }

        /* CARD */

        .card {
            background: white;

            padding: 22px;

            border-radius: 10px;

            box-shadow:
                0 2px 8px
                rgba(0,0,0,.06);

            margin-bottom: 20px;
        }

        /* BUTTON */

        .btn {
            display: inline-block;

            border: none;

            border-radius: 7px;

            padding: 10px 15px;

            cursor: pointer;

            font-size: 13px;
        }

        .btn-primary {
            background: #2563eb;
            color: white;
        }

        .btn-success {
            background: #16a34a;
            color: white;
        }

        .btn-warning {
            background: #f59e0b;
            color: white;
        }

        .btn-danger {
            background: #dc2626;
            color: white;
        }

        .btn-secondary {
            background: #6b7280;
            color: white;
        }

        .btn:hover {
            opacity: .85;
        }

        /* TABLE */

        .table-container {
            width: 100%;

            overflow-x: auto;
        }

        table {
            width: 100%;

            border-collapse: collapse;
        }

        th {
            padding: 12px;

            background: #eff6ff;

            color: #1e3a8a;

            text-align: left;

            font-size: 13px;
        }

        td {
            padding: 12px;

            border-bottom:
                1px solid #e5e7eb;

            font-size: 13px;
        }

        tr:hover td {
            background: #f8fafc;
        }

        /* FORM */

        .form-group {
            margin-bottom: 18px;
        }

        .form-group label {
            display: block;

            margin-bottom: 7px;

            font-weight: bold;

            font-size: 13px;
        }

        .form-control {
            width: 100%;

            padding: 11px 12px;

            border:
                1px solid #d1d5db;

            border-radius: 7px;

            font-size: 14px;
        }

        .form-control:focus {
            outline: none;

            border-color: #2563eb;
        }

        /* ALERT */

        .alert {
            padding: 13px 15px;

            border-radius: 7px;

            margin-bottom: 18px;

            font-size: 13px;
        }

        .alert-success {
            background: #dcfce7;

            color: #166534;
        }

        .alert-danger {
            background: #fee2e2;

            color: #991b1b;
        }

        .alert-warning {
            background: #fef3c7;

            color: #92400e;
        }

        .alert-info {
            background: #dbeafe;

            color: #1e40af;
        }

        /* FOOTER */

        .footer {
            margin-top: 25px;

            padding: 18px;

            text-align: center;

            color: #777;

            font-size: 12px;
        }

        /* MOBILE */

        @media (max-width: 800px) {

            .sidebar {
                position: relative;

                width: 100%;

                height: auto;
            }

            .main-content {
                margin-left: 0;

                padding: 15px;
            }

            .top-navbar {
                flex-direction: column;

                align-items: flex-start;

                gap: 15px;
            }

            .navbar-user {
                width: 100%;

                justify-content:
                    space-between;
            }

        }

    </style>

</head>

<body>