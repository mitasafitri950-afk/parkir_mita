<div class="footer">

    © <?php echo date("Y"); ?>

    <strong>
        Parkir Mita
    </strong>

    — Sistem Informasi Parkir

</div>

</body>

</html>